import { HOY, ID, LUNES_SIGUIENTE, MANANA, abrirCancha, celda, columna, continuar, estado, expect, leerEstado, libres, reserva, test, titulo } from '../support/demo.js'

const confirmar = (page) => page.getByRole('button', { name: 'Confirmar reserva' })
const panel = (page) => page.getByText('Franja seleccionada').locator('visible=true').locator('../..')
/** Cancha de prueba sin ocupación simulada: no depende del azar de la fecha. */
const reservarPrimera = async (page, day = 1) => {
  await libres(page, day).first().click()
  await continuar(page)
  await expect(titulo(page, 'Confirma tu reserva')).toBeVisible()
  await page.waitForTimeout(800) // QA-30: la pantalla se monta dos veces y descarta lo tecleado antes
}

test.describe('Entrada y sesión', () => {
  test('[ACC-01][ACC-02] rutas sin sesión y botón deshabilitado @firefox', async ({ page }) => {
    for (const p of ['/', '/xyz', '/app/inicio', '/admin']) {
      await page.goto(p)
      await expect(page).toHaveURL(/bienvenida/)
    }
    await page.getByRole('button', { name: 'Iniciar sesión' }).click()
    const boton = page.getByRole('button', { name: 'Solicitar código' })
    await expect(boton).toBeDisabled()
    await page.getByLabel('Correo institucional').fill('   ')
    await expect(boton).toBeDisabled()
  })

  test('[ACC-03][ACC-04][ACC-06] dominio no permitido', async ({ page }) => {
    for (const email of ['alguien@gmail.com', 'a@unimagdalena.edu.co.evil.com']) {
      await page.goto('/acceso')
      await page.getByLabel('Correo institucional').fill(email)
      await page.getByRole('button', { name: 'Solicitar código' }).click()
      await expect(page.getByText(`${email} no pertenece`)).toBeVisible()
      await expect(page.getByText('No se envió ningún correo')).toBeVisible()
    }
    await page.getByRole('button', { name: 'Volver a intentar' }).click()
    await expect(page.getByLabel('Correo institucional')).toBeEditable()
  })

  test('[ACC-05] correo mal escrito no navega', async ({ page }) => {
    await page.goto('/acceso')
    for (const email of ['sin-arroba', 'a@b@unimagdalena.edu.co']) {
      await page.getByLabel('Correo institucional').fill(email)
      await page.getByRole('button', { name: 'Solicitar código' }).click()
      await expect(page).toHaveURL(/\/acceso$/)
    }
  })

  test('[ACC-07] sin backend avisa y se queda', async ({ page }) => {
    await page.route('**/api/**', (r) => r.abort())
    await page.goto('/acceso')
    await page.getByLabel('Correo institucional').fill('ana@unimagdalena.edu.co')
    await page.getByRole('button', { name: 'Solicitar código' }).click()
    await expect(page.getByText('No pudimos enviar el código')).toBeVisible()
    await expect(page).toHaveURL(/\/acceso$/)
  })

  test('[ACC-20] /acceso/codigo directo vuelve a /acceso', async ({ page }) => {
    await page.goto('/acceso/codigo')
    await expect(page).toHaveURL(/\/acceso$/)
  })

  test('[ACC-40][ACC-52] la sesión sobrevive a recargar; el acceso redirige @movil @firefox', async ({ page, demo }) => {
    await demo({ role: null })
    await page.goto('/')
    await page.getByRole('button', { name: 'Entrar como estudiante' }).click()
    await expect(titulo(page, 'Hola, María')).toBeVisible()
    await page.reload()
    await expect(titulo(page, 'Hola, María')).toBeVisible()
    for (const p of ['/bienvenida', '/acceso']) {
      await page.goto(p)
      await expect(page).toHaveURL(/app\/inicio/)
    }
  })

  test('[ACC-41] el estudiante no entra al administrador', async ({ page, demo }) => {
    await demo()
    for (const p of ['/admin', '/admin/espacios', '/admin/bloqueos', '/admin/reglas', '/admin/espacios/qr']) {
      await page.goto(p)
      await expect(page).toHaveURL(/app\/inicio/)
    }
  })

  test('[ACC-44][ACC-45] cerrar sesión borra el token y Atrás no muestra datos', async ({ page, demo }) => {
    await demo()
    await page.goto('/app/mis-reservas')
    await page.locator('header button').last().click()
    await page.getByRole('menuitem', { name: 'Cerrar sesión' }).click()
    await expect(page).toHaveURL(/bienvenida/)
    expect(await page.evaluate(() => localStorage.getItem('ud-token'))).toBeNull()
    expect(await page.context().cookies()).toEqual([])
    await page.goBack()
    await expect(page.getByText('María')).toBeHidden()
  })

  test('[ACC-47] la demo conserva el destino', async ({ page, demo }) => {
    test.fail(true, 'QA-08')
    await demo({ role: null })
    await page.goto(`/checkin/${ID.multiple1}`)
    await page.getByRole('button', { name: 'Entrar como estudiante' }).click()
    await expect(page).not.toHaveURL(/bienvenida/)
    await expect(page).toHaveURL(/checkin/, { timeout: 3000 })
  })
})

test.describe('Disponibilidad', () => {
  test('[DIS-01][DIS-02] cuatro canchas en orden y con sus datos @movil', async ({ page, demo }) => {
    await demo()
    await page.goto('/app/disponibilidad')
    const cards = page.getByRole('button', { name: /Ver horario/ })
    await expect(cards).toHaveCount(4)
    const names = await cards.locator('p.font-display').allTextContents()
    expect(names).toEqual([...names].sort((a, b) => a.localeCompare(b, 'es')))
    await expect(page.getByText('Cancha fútbol 5')).toHaveCount(0)
    await expect(cards.filter({ hasText: 'tenis 1' })).toContainText('6:00 a. m. – 6:00 p. m.')
    await expect(cards.filter({ hasText: 'tenis 1' })).toContainText('Aforo 4')
  })

  test('[DIS-03] las franjas libres de hoy coinciden con el calendario', async ({ page, demo }) => {
    await demo()
    await page.goto('/app/disponibilidad')
    const card = page.getByRole('button', { name: /múltiple 1.*Ver horario/ })
    await expect(card).toContainText(/franjas? libres? hoy|Sin franjas/)
    const n = Number(/(\d+) franjas? libre/.exec(await card.textContent())?.[1] ?? 0)
    await card.click()
    await expect(page.getByText(/En vivo/)).toBeVisible()
    await expect(libres(page, 0)).toHaveCount(n)
  })

  test('[DIS-04] singular con una sola franja', async ({ page, demo }) => {
    test.fail(true, 'QA-09')
    const state = estado()
    state.spaces = [state.spaces[0]]
    await demo({ state })
    await abrirCancha(page)
    const horas = await columna(page, 0).locator('button').evaluateAll((els) => els.flatMap((e, i) => (e.disabled ? [] : [8 + i])))
    expect(horas.length).toBeGreaterThan(1)
    await page.evaluate(({ horas, id, date }) => {
      const k = 'ud-demo-state-v1', s = JSON.parse(localStorage.getItem(k))
      s.blocks = horas.slice(1).map((h) => ({ id: `b${h}`, spaceId: id, date, startHour: h, endHour: h + 1, reason: 'x', type: 'CLASS' }))
      localStorage.setItem(k, JSON.stringify(s))
    }, { horas, id: ID.multiple1, date: HOY })
    await page.goto('/app/disponibilidad')
    await expect(page.getByRole('button', { name: /múltiple 1.*1 franjas? libres? hoy/ })).toBeVisible()
    await expect(page.getByRole('button', { name: /1 franja libre hoy/ })).toBeVisible({ timeout: 1500 })
  })

  test('[DIS-05] sin canchas activas', async ({ page, demo }) => {
    const state = estado()
    state.spaces.forEach((s) => (s.status = 'MAINTENANCE'))
    await demo({ state })
    await page.goto('/app/disponibilidad')
    await expect(page.getByText('No hay espacios disponibles')).toBeVisible()
  })

  test('[DIS-06] cancha inexistente o en mantenimiento', async ({ page, demo }) => {
    await demo()
    for (const id of ['no-existe', ID.futbol5]) {
      await page.goto(`/app/disponibilidad/${id}`)
      await expect(page).toHaveURL(/disponibilidad$/)
    }
  })

  test('[DIS-10][DIS-11][DIS-12] 7 días, horizonte y pasado', async ({ page, demo }) => {
    await demo()
    await abrirCancha(page)
    await expect(page.locator('[aria-busy] > div.border-l')).toHaveCount(7)
    await expect(columna(page, 0).locator('button')).toHaveCount(12)
    for (const h of [8, 9]) await expect(celda(page, 0, h)).toBeDisabled()
    await page.getByRole('button', { name: 'Semana siguiente' }).click()
    await expect(page.getByRole('button', { name: 'Semana siguiente' })).toBeDisabled()
    await expect.poll(() => columna(page, 1).locator('button:not([disabled])').count()).toBe(0)
  })

  test('[DIS-11] la demo usa el mismo horizonte que el backend (hoy + 6)', async ({ page, demo }) => {
    test.fail(true, 'QA-28: el simulador quedó en 7 días y el backend pasó a 6')
    await demo()
    await page.goto('/app/mis-reservas/reglas')
    const fila = page.locator('dl > div', { hasText: 'Anticipación máxima' })
    await expect(fila).toContainText(/\d días/)
    await page.waitForTimeout(1000)
    await expect(fila).toContainText('6 días', { timeout: 1500 })
  })

  for (const [id, min, ok] of [['DIS-13', 9, true], ['DIS-14', 11, false]]) {
    test(`[${id}] minuto ${min} de la franja en curso`, async ({ page, demo }) => {
      // se busca una hora libre de hoy para situar el reloj dentro de ella
      await demo({ time: `${HOY}T06:00:00-05:00` })
      await abrirCancha(page)
      const label = await libres(page, 0).first().getAttribute('aria-label')
      const index = await columna(page, 0).locator('button').evaluateAll((els, l) => els.findIndex((e) => e.getAttribute('aria-label') === l), label)
      const hour = 8 + index
      await page.clock.setFixedTime(new Date(`${HOY}T${String(hour).padStart(2, '0')}:${String(min).padStart(2, '0')}:00-05:00`))
      await abrirCancha(page)
      await expect(celda(page, 0, hour)).toBeEnabled({ enabled: ok })
    })
  }

  test('[DIS-15][DIS-16] motivos visibles y sin nombres', async ({ page, demo }) => {
    await demo({ state: estado({ blocks: [{ id: 'b', spaceId: ID.multiple1, date: MANANA, startHour: 9, endHour: 11, reason: 'Torneo interno', type: 'EVENT' }] }) })
    await abrirCancha(page)
    await expect(columna(page, 1).locator('[title^="Torneo interno · 9:00 a. m."]')).toBeVisible()
    for (const t of await page.locator('[title^="Reservada"]').allTextContents()) expect(t).toMatch(/^Reservada/)
  })

  test('[DIS-17] la propia se distingue al entrar desde el menú', async ({ page, demo }) => {
    await demo({ state: estado({ reservations: [reserva('r', { hour: 14 })] }) })
    await page.goto('/app/inicio')
    await expect(page.getByText('Próxima: Cancha múltiple 1')).toBeVisible()
    await page.getByRole('button', { name: 'Consultar disponibilidad' }).click()
    await page.getByRole('button', { name: /múltiple 1.*Ver horario/ }).click()
    await expect(page.locator('[title^="Tu reserva"]')).toBeVisible()
  })

  test('[DIS-19] cambiar de disciplina no cambia la ocupación', async ({ page, demo }) => {
    await demo()
    await abrirCancha(page)
    const titles = () => page.locator('[aria-busy="false"] [title]').evaluateAll((e) => e.map((x) => x.title))
    const before = await titles()
    expect(before.length).toBeGreaterThan(0)
    await page.getByRole('button', { name: 'Voleibol' }).click()
    await expect(page.getByRole('button', { name: 'Voleibol' })).toHaveAttribute('aria-pressed', 'true')
    await page.waitForTimeout(1000)
    await expect.poll(titles).toEqual(before)
  })

  test('[DIS-20] la línea roja marca la hora', async ({ page, demo }) => {
    await demo()
    await abrirCancha(page)
    await expect(columna(page, 0).locator('div.z-20')).toHaveAttribute('style', /top: 130px/) // (10,5−8)×52
  })

  test.describe('otra zona horaria', () => {
    test.use({ timezoneId: 'Europe/Madrid' })
    test('[DIS-21] la línea sigue en hora de Bogotá', async ({ page, demo }) => {
      test.fail(true, 'QA-04')
      await demo()
      await abrirCancha(page)
      await expect(columna(page, 0).locator('div.z-20')).toHaveAttribute('style', /top: 130px/, { timeout: 3000 })
    })
    test('[TRX-55] reservar y ver la cuota desde otra zona', async ({ page, demo }) => {
      await demo()
      await abrirCancha(page)
      await reservarPrimera(page, 1)
      await expect(page.locator('dl')).toContainText('Miércoles, 25 de noviembre')
      await confirmar(page).click()
      await expect(titulo(page, 'Reserva confirmada')).toBeVisible()
      await page.goto('/app/mis-reservas/cuota')
      await expect(page.getByText('23 de noviembre al 29 de noviembre', { exact: false })).toBeVisible()
    })
  })

  test('[DIS-22] semana que cruza de mes', async ({ page, demo }) => {
    await demo({ time: '2026-11-27T10:30:00-05:00' })
    await abrirCancha(page)
    await expect(page.getByRole('heading', { level: 2, name: /Nov.*diciembre/i })).toBeVisible()
  })
})

test.describe('Selección', () => {
  const seguidas = async (page, n) => {
    for (let d = 1; d < 7; d++) {
      const enabled = await columna(page, d).locator('button').evaluateAll((els) => els.map((e) => !e.disabled))
      for (let i = 0; i + n <= enabled.length; i++) if (enabled.slice(i, i + n).every(Boolean)) return { d, i }
    }
    throw new Error(`sin ${n} franjas libres seguidas`)
  }
  const fila = (page, { d, i }, k = 0) => columna(page, d).locator('button').nth(i + k)

  test('[DIS-30][DIS-31][DIS-32][DIS-35] clic, extender, límite y quitar', async ({ page, demo }) => {
    await demo()
    await abrirCancha(page)
    const s = await seguidas(page, 3)
    await fila(page, s).click()
    await expect(panel(page)).toContainText('· 1 h ·')
    await fila(page, s, 1).click({ force: true })
    await expect(panel(page)).toContainText('· 2 h ·')
    await fila(page, s, 2).click({ force: true })
    await expect(panel(page)).toContainText('· 1 h ·')
    await page.getByRole('button', { name: 'Quitar' }).locator('visible=true').click()
    await expect(page.getByText('Franja seleccionada').locator('visible=true')).toHaveCount(0)
    await fila(page, s).click()
    await fila(page, s).click({ force: true })
    await expect(page.getByText('Franja seleccionada').locator('visible=true')).toHaveCount(0)
  })

  test('[DIS-33] arrastrar se limita a 2 h', async ({ page, demo }) => {
    await demo()
    await abrirCancha(page)
    const s = await seguidas(page, 3)
    await fila(page, s).scrollIntoViewIfNeeded()
    const a = await fila(page, s).boundingBox(), b = await fila(page, s, 2).boundingBox()
    await page.mouse.move(a.x + 20, a.y + 20)
    await page.mouse.down()
    await page.mouse.move(b.x + 20, b.y + 20, { steps: 10 })
    await page.mouse.up()
    await expect(panel(page)).toContainText('· 2 h ·')
  })

  test('[DIS-34] arrastrar sobre una ocupada no la incluye', async ({ page, demo }) => {
    await demo()
    await abrirCancha(page)
    let hit
    for (let d = 1; d < 7 && !hit; d++) {
      const e = await columna(page, d).locator('button').evaluateAll((els) => els.map((x) => !x.disabled))
      const i = e.findIndex((v, k) => v && e[k + 1] === false)
      if (i >= 0) hit = { d, i }
    }
    await fila(page, hit).scrollIntoViewIfNeeded()
    const a = await fila(page, hit).boundingBox()
    await page.mouse.move(a.x + 20, a.y + 20)
    await page.mouse.down()
    await page.mouse.move(a.x + 20, a.y + 80, { steps: 6 })
    await page.mouse.up()
    await expect(panel(page)).toContainText('· 1 h ·')
  })

  test('[DIS-36] solo queda la última, aunque sea otro día', async ({ page, demo }) => {
    await demo()
    await abrirCancha(page)
    await libres(page, 1).first().click()
    await libres(page, 2).first().click()
    await expect(panel(page)).toContainText('Jueves, 26 de noviembre')
    await expect(page.getByText('Nueva reserva', { exact: true })).toHaveCount(1)
  })

  test('[DIS-37][TRX-20] reservar solo con teclado @firefox', async ({ page, demo }) => {
    await demo()
    await abrirCancha(page)
    const cell = libres(page, 1).first()
    await cell.focus()
    await page.keyboard.press('Enter')
    await expect(panel(page)).toContainText('· 1 h ·')
    const next = page.getByRole('button', { name: /^Continuar/ }).locator('visible=true')
    await next.focus()
    await page.keyboard.press('Enter')
    await expect(titulo(page, 'Confirma tu reserva')).toBeVisible()
    await confirmar(page).focus()
    await page.keyboard.press('Enter')
    await expect(titulo(page, 'Reserva confirmada')).toBeVisible()
  })
})

test.describe('Reservar', () => {
  test('[RES-01][RES-03][MIS-40] reserva, comprobante y cuota @movil @firefox', async ({ page, demo, errores, isMobile }) => {
    await demo()
    await abrirCancha(page)
    if (isMobile) {
      await page.getByRole('button', { name: /Miércoles, 25/ }).click()
      await page.locator('[aria-busy] button:not([disabled])').locator('visible=true').first().click()
      await continuar(page)
    } else await reservarPrimera(page)
    await expect(page.locator('dl')).toContainText('Miércoles, 25 de noviembre')
    await confirmar(page).click()
    await expect(titulo(page, 'Reserva confirmada')).toBeVisible()
    await page.getByRole('button', { name: 'Ir a Mis reservas' }).click()
    await expect(page.getByRole('tab', { name: 'Próximas (1)' })).toBeVisible()
    await page.goto('/app/inicio')
    await expect(page.getByText('3 h disponibles')).toBeVisible()
    await page.goto('/app/mis-reservas/cuota')
    await expect(page.getByText('Cuota máxima: 4 h')).toBeVisible()
    expect(errores.filter((e) => !/panorama|WebGL|GL Driver/i.test(e))).toEqual([])
  })

  test('[RES-05] doble clic crea una sola', async ({ page, demo }) => {
    await demo()
    await abrirCancha(page)
    await reservarPrimera(page)
    await confirmar(page).dblclick()
    await expect(titulo(page, 'Reserva confirmada')).toBeVisible()
    expect((await leerEstado(page)).reservations).toHaveLength(1)
  })

  test('[RES-06] conflicto y regreso a la misma cancha', async ({ page, demo }) => {
    await demo({ random: 0.05 })
    await abrirCancha(page)
    await reservarPrimera(page)
    await confirmar(page).click()
    await expect(titulo(page, 'La franja ya no está disponible')).toBeVisible()
    await page.getByRole('button', { name: /Volver al calendario/ }).click()
    await expect(page).toHaveURL(new RegExp(ID.multiple1))
    expect((await leerEstado(page)).reservations).toHaveLength(0)
  })

  test('[RES-07] solape con otra cancha', async ({ page, demo }) => {
    const all = Array.from({ length: 6 }, (_, i) => reserva(`r${i}`, { space: ID.tenis1, date: MANANA, hour: 8 + 2 * i, hours: 2 }))
    await demo({ state: estado({ reservations: all, params: { weeklyHours: 40, noShows: 3 } }) })
    await abrirCancha(page)
    await reservarPrimera(page)
    await expect(page.getByText('Se cruza con otra reserva tuya')).toBeVisible()
    await expect(confirmar(page)).toBeDisabled()
  })

  test('[RES-09] cuota agotada esta semana', async ({ page, demo }) => {
    await demo({ state: estado({ reservations: [reserva('a', { date: HOY, hour: 6, hours: 4, space: ID.tenis1, status: 'COMPLETED' })] }) })
    await abrirCancha(page)
    await reservarPrimera(page, 1)
    await expect(page.getByText('solo te quedan 0 h esta semana')).toBeVisible()
    await expect(confirmar(page)).toBeDisabled()
  })

  test('[RES-11] semana siguiente con la actual agotada', async ({ page, demo }) => {
    test.fail(true, 'QA-01')
    await demo({ state: estado({ reservations: [reserva('a', { date: HOY, hour: 6, hours: 4, space: ID.tenis1, status: 'COMPLETED' })] }) })
    await abrirCancha(page)
    await reservarPrimera(page, 6)
    await expect(page.locator('dl')).toContainText('30 de noviembre')
    expect(LUNES_SIGUIENTE).toBe('2026-11-30')
    await expect(confirmar(page)).toBeEnabled({ timeout: 3000 })
  })

  test('[RES-12] la semana siguiente también tiene su límite', async ({ page, demo }) => {
    await demo({ state: estado({ reservations: [reserva('a', { date: LUNES_SIGUIENTE, hour: 6, hours: 4, space: ID.tenis1 })] }) })
    await abrirCancha(page)
    const free = libres(page, 6)
    const label = await free.last().getAttribute('aria-label')
    expect(label).toBeTruthy()
    await free.last().click()
    await continuar(page)
    await confirmar(page).click()
    await expect(page.getByText(/supera tu cuota semanal|solapa/)).toBeVisible()
  })

  test('[RES-13] pasa la tolerancia antes de confirmar', async ({ page, demo }) => {
    await demo({ time: `${HOY}T06:00:00-05:00` })
    await abrirCancha(page)
    const label = await libres(page, 0).first().getAttribute('aria-label')
    await libres(page, 0).first().click()
    await continuar(page)
    const hour = 8 + (await page.evaluate((l) => ({ '8': 0, '9': 1, '10': 2, '11': 3, '12': 4, '1': 5, '2': 6, '3': 7, '4': 8, '5': 9, '6': 10, '7': 11 })[l.split(':')[0]], label))
    await page.clock.setFixedTime(new Date(`${HOY}T${String(hour).padStart(2, '0')}:11:00-05:00`))
    await confirmar(page).click()
    await expect(page.getByText('La franja ya no se puede reservar')).toBeVisible()
  })

  test('[RES-14][RES-15] sin borrador vuelve; volver no crea nada', async ({ page, demo }) => {
    await demo()
    await page.goto('/app/reservar')
    await expect(page).toHaveURL(/disponibilidad$/)
    await abrirCancha(page)
    await reservarPrimera(page)
    await page.getByRole('button', { name: 'Volver al calendario' }).click()
    await expect(page).toHaveURL(new RegExp(ID.multiple1))
    expect((await leerEstado(page)).reservations).toHaveLength(0)
  })

  test('[RES-16][RES-17] Atrás no duplica y recargar conserva el comprobante', async ({ page, demo }) => {
    await demo()
    await abrirCancha(page)
    await reservarPrimera(page)
    await confirmar(page).click()
    await expect(titulo(page, 'Reserva confirmada')).toBeVisible()
    await page.reload()
    await expect(titulo(page, 'Reserva confirmada')).toBeVisible()
    await page.goBack()
    await expect(confirmar(page)).toBeHidden()
    expect((await leerEstado(page)).reservations).toHaveLength(1)
  })

  test('[RES-30][RES-31][RES-33][RES-34] implementos', async ({ page, demo }) => {
    await demo()
    await abrirCancha(page)
    await reservarPrimera(page)
    await expect(page.getByText('Balón de baloncesto')).toBeVisible()
    await expect(page.getByText('Petos')).toBeVisible()
    await expect(page.getByText(/voleibol/i)).toHaveCount(0)
    const campo = page.getByLabel('Cantidad de Balón de baloncesto')
    for (const [v, ok] of [['99', '10'], ['-5', '0']]) {
      await campo.fill(v)
      await campo.blur()
      await expect(campo).toHaveValue(ok)
    }
    await campo.fill('2')
    await campo.blur()
    await confirmar(page).click()
    await expect(page.getByText('2 × Balón de baloncesto')).toBeVisible()
    await page.getByRole('button', { name: 'Ir a Mis reservas' }).click()
    await expect(page.getByText('2 × Balón de baloncesto')).toBeVisible()
  })

  test('[RES-32] voleibol no ofrece la malla inactiva', async ({ page, demo }) => {
    await demo()
    await abrirCancha(page)
    await page.getByRole('button', { name: 'Voleibol' }).click()
    await reservarPrimera(page)
    await expect(page.getByText('Balón de voleibol')).toBeVisible()
    await expect(page.getByText('Malla')).toHaveCount(0)
  })
})

test.describe('Mis reservas', () => {
  test('[MIS-01][MIS-02][MIS-03] orden, estados y botones @movil', async ({ page, demo }) => {
    await demo({
      state: estado({
        reservations: [
          reserva('b', { date: MANANA, hour: 9 }), reserva('a', { hour: 14 }),
          reserva('v', { date: '2026-11-16', hour: 9, status: 'NO_SHOW' }), reserva('c', { date: '2026-11-21', hour: 9, status: 'COMPLETED' }),
        ],
      }),
    })
    await page.goto('/app/mis-reservas')
    await expect(page.getByRole('tab', { name: 'Próximas (2)' })).toBeVisible()
    await expect(page.locator('main p.font-display + p').first()).toContainText('Hoy')
    await page.getByRole('tab', { name: 'Historial (2)' }).click()
    await expect(page.getByText('Completada')).toBeVisible()
    await expect(page.getByText('Inasistencia')).toBeVisible()
    await expect(page.getByRole('button', { name: 'Cancelar' })).toHaveCount(0)
  })

  test('[MIS-04] una terminada no ofrece Cancelar', async ({ page, demo }) => {
    test.fail(true, 'QA-06')
    await demo({ state: estado({ reservations: [reserva('a', { hour: 8 })] }) })
    await page.goto('/app/mis-reservas')
    await page.getByRole('tab', { name: 'Historial (1)' }).click()
    await expect(page.getByText('Confirmada')).toBeVisible()
    await expect(page.getByRole('button', { name: 'Cancelar' })).toHaveCount(0, { timeout: 2000 })
  })

  test('[MIS-05][MIS-06] en uso sin Cancelar; acceso al check-in solo hoy', async ({ page, demo }) => {
    await demo({ state: estado({ reservations: [reserva('a', { hour: 10, status: 'IN_USE' })] }) })
    await page.goto('/app/mis-reservas')
    await expect(page.getByText('En uso')).toBeVisible()
    await expect(page.getByRole('button', { name: 'Cancelar' })).toHaveCount(0)
    await page.getByRole('button', { name: 'Ver check-in' }).click()
    await expect(page).toHaveURL(/checkin/)
  })

  for (const [id, hour, tipo, horas, estadoFinal] of [['MIS-20][MIS-21', 11.52, 'a tiempo', '0', 'Cancelada a tiempo'], ['MIS-22][MIS-23', 11.48, 'tardía', '1', 'Cancelada tardía'], ['MIS-24', 10.4, 'tardía', '1', 'Cancelada tardía']]) {
    test(`[${id}] inicio ${hour}: ${tipo} @movil`, async ({ page, demo }) => {
      await demo({ state: estado({ reservations: [reserva('a', { hour })] }) })
      await page.goto('/app/mis-reservas')
      await page.getByRole('button', { name: 'Cancelar' }).click()
      await expect(page.getByText(`Cancelación ${tipo}`, { exact: true })).toBeVisible()
      await page.getByRole('button', { name: 'Confirmar cancelación' }).click()
      await expect(page.getByRole('tab', { name: 'Historial (1)' })).toBeVisible()
      await page.getByRole('tab', { name: 'Historial (1)' }).click()
      await expect(page.getByText(estadoFinal)).toBeVisible()
      await page.goto('/app/inicio')
      await expect(page.getByText(`${4 - Number(horas)} h disponibles`)).toBeVisible()
    })
  }

  test('[MIS-25] decide el momento de confirmar', async ({ page, demo }) => {
    await demo({ state: estado({ reservations: [reserva('a', { hour: 11.52 })] }) })
    await page.goto('/app/mis-reservas/cancelar/a')
    await expect(page.getByText('Cancelación a tiempo')).toBeVisible()
    await page.clock.setFixedTime(new Date(`${HOY}T10:33:00-05:00`))
    await page.getByRole('button', { name: 'Confirmar cancelación' }).click()
    await expect(page.getByText('Reserva cancelada (tardía)')).toBeVisible()
  })

  test('[MIS-26][MIS-27][MIS-29] volver, en uso e inexistente', async ({ page, demo }) => {
    await demo({ state: estado({ reservations: [reserva('a', { hour: 14 }), reserva('u', { hour: 10, status: 'IN_USE' })] }) })
    for (const id of ['u', 'no-existe']) {
      await page.goto(`/app/mis-reservas/cancelar/${id}`)
      await expect(page.getByText('Esta reserva no se puede cancelar')).toBeVisible()
    }
    await page.goto('/reservations/a/cancel') // [MIS-30]
    await expect(page).toHaveURL(/mis-reservas\/cancelar\/a/)
    await page.getByRole('button', { name: 'Volver' }).click()
    await expect(page).toHaveURL(/mis-reservas$/)
    expect((await leerEstado(page)).reservations[0].status).toBe('CONFIRMED')
  })

  test('[MIS-41][MIS-42] movimientos y semana', async ({ page, demo }) => {
    await demo({ state: estado({ reservations: [reserva('a', { hour: 6, hours: 2, space: ID.tenis1, status: 'COMPLETED' }), reserva('b', { date: MANANA, hour: 9, status: 'CANCELLED_ON_TIME' }), reserva('c', { date: MANANA, hour: 12, status: 'CANCELLED_LATE' })] }) })
    await page.goto('/app/mis-reservas/cuota')
    await expect(page.getByText('23 de noviembre al 29 de noviembre', { exact: false })).toBeVisible()
    await expect(page.getByText('Lunes, 30 de noviembre')).toBeVisible()
    const horas = await page.locator('main li span.tabular-nums').allTextContents()
    expect(horas.map((h) => parseInt(h)).reduce((a, b) => a + b, 0)).toBe(3)
    await expect(page.getByText('3 h').or(page.locator('p', { hasText: /^3 h$/ })).first()).toBeVisible()
  })

  test('[MIS-43] cuota menor que lo usado', async ({ page, demo }) => {
    await demo({ state: estado({ params: { weeklyHours: 1, noShows: 3 }, reservations: [reserva('a', { hour: 6, hours: 2, space: ID.tenis1, status: 'COMPLETED' })] }) })
    await page.goto('/app/inicio')
    await expect(page.getByText('0 h disponibles')).toBeVisible()
  })

  test('[MIS-50][MIS-52][MIS-53] reglas, preguntas y rutas antiguas', async ({ page, demo }) => {
    await demo()
    await page.goto('/app/reglas')
    await expect(page).toHaveURL(/mis-reservas\/reglas/)
    await expect(page.getByText('4 horas', { exact: true })).toBeVisible()
    const q = page.getByRole('button', { name: '¿Qué pasa si no asisto?' })
    await q.focus()
    await page.keyboard.press('Enter')
    await expect(page.getByText(/Con 3 inasistencias/)).toBeVisible()
    await page.goto('/app/mi-cuota')
    await expect(page).toHaveURL(/mis-reservas\/cuota/)
  })
})

test.describe('Check-in', () => {
  const entrar = (page) => page.getByRole('button', { name: 'Confirmar asistencia' })
  const ir = (page, id = ID.multiple1) => page.goto(`/checkin/${id}`)

  for (const [id, hour, texto] of [['CHK-01', 10.7, 'Aún es temprano'], ['CHK-02', 10.65, 'Asistencia confirmada'], ['CHK-03', 10, 'Asistencia confirmada'], ['CHK-04', 9.48, 'No tienes una reserva activa aquí']]) {
    test(`[${id}] inicio ${hour}: ${texto} @movil`, async ({ page, demo }) => {
      await demo({ state: estado({ reservations: [reserva('a', { hour })] }) })
      await ir(page)
      await entrar(page).click()
      await expect(page.getByText(texto, { exact: true })).toBeVisible()
    })
  }

  test('[CHK-05][CHK-11] otra cancha e inexistente', async ({ page, demo }) => {
    await demo({ state: estado({ reservations: [reserva('a', { hour: 10.6 })] }) })
    for (const id of [ID.tenis1, 'no-existe']) {
      await ir(page, id)
      await entrar(page).click()
      await expect(page.getByText('No tienes una reserva activa aquí')).toBeVisible()
    }
  })

  test('[CHK-06][CHK-07] persiste y ya no se cancela', async ({ page, demo }) => {
    await demo({ state: estado({ reservations: [reserva('a', { hour: 10.6 })] }) })
    await ir(page)
    await entrar(page).click()
    await expect(page.getByText('Asistencia confirmada')).toBeVisible()
    await page.reload()
    await expect(page.getByText('Asistencia confirmada')).toBeVisible()
    await page.goto('/app/mis-reservas/cancelar/a')
    await expect(page.getByText('ya tiene check-in')).toBeVisible()
  })

  test('[CHK-08] la segunda reserva del día tras una en uso ya terminada', async ({ page, demo }) => {
    test.fail(true, 'QA-05')
    await demo({ state: estado({ reservations: [reserva('a', { hour: 8, status: 'IN_USE' }), reserva('b', { hour: 10.6 })] }) })
    await ir(page)
    await expect(titulo(page, 'Check-in del espacio')).toBeVisible()
    await page.waitForTimeout(1500)
    await expect(entrar(page)).toBeVisible({ timeout: 2000 })
  })

  test('[CHK-09] dos futuras: la más próxima', async ({ page, demo }) => {
    await demo({ state: estado({ reservations: [reserva('tarde', { hour: 15 }), reserva('pronto', { hour: 10.6 })] }) })
    await ir(page)
    await entrar(page).click()
    await expect(page.getByText('Asistencia confirmada')).toBeVisible()
    const s = await leerEstado(page)
    expect(s.reservations.find((r) => r.id === 'pronto').status).toBe('IN_USE')
    expect(s.reservations.find((r) => r.id === 'tarde').status).toBe('CONFIRMED')
  })

  test('[CHK-10] cancelada', async ({ page, demo }) => {
    await demo({ state: estado({ reservations: [reserva('a', { hour: 10.6, status: 'CANCELLED_LATE' })] }) })
    await ir(page)
    await entrar(page).click()
    await expect(page.getByText('No tienes una reserva activa aquí')).toBeVisible()
  })

  test('[CHK-12] ventana a medianoche', async ({ page, demo }) => {
    test.fail(true, 'QA-07')
    const state = estado({ reservations: [reserva('a', { hour: 0 })] })
    state.spaces[0].openingTime = '00:00'
    await demo({ state, time: `${HOY}T00:05:00-05:00` })
    await ir(page)
    await expect(page.getByText('Ventana de check-in')).toBeVisible()
    await expect(page.getByText('Ventana de check-in')).toContainText('11:50 p. m.', { timeout: 2000 })
  })
})


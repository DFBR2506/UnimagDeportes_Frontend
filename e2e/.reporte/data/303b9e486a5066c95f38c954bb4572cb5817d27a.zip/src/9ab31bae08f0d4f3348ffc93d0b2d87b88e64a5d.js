import { HOY, ID, MANANA, abrirCancha, celda, columna, dialogo, elegir, entrarComo, estado, expect, leerEstado, libres, reserva, test, titulo } from '../support/demo.js'
import { png } from '../stack/png.mjs'

const admin = (extra) => ({ role: 'admin', ...extra })
const archivo = (buffer = png(200, 100), name = 'a.png', mimeType = 'image/png') => ({ name, mimeType, buffer })
const fila = (page, name) => page.getByRole('row', { name })

test.describe('Panel', () => {
  test('[ADM-01][ADM-02] indicadores por semana y mes @movil', async ({ page, demo }) => {
    await demo(admin())
    await page.goto('/admin')
    for (const t of ['Reservas', 'Cancelaciones tardías', 'Inasistencias', 'Usuarios suspendidos']) await expect(page.getByText(t, { exact: true })).toBeVisible()
    await expect(page.getByText('· 23 nov – 29 nov', { exact: true })).toBeVisible()
    await page.getByRole('button', { name: 'Mes' }).click()
    await expect(page.getByText('· 1 nov – 30 nov', { exact: true })).toBeVisible()
  })

  test('[ADM-03][ADM-04] cambia de cancha y avisa mantenimiento', async ({ page, demo }) => {
    await demo(admin())
    await page.goto('/admin')
    await elegir(page, 'Cancha', 'Cancha fútbol 5 (mantenimiento)')
    await expect(page.getByRole('heading', { name: 'Cancha fútbol 5' })).toBeVisible()
    await expect(page.getByText('Esta cancha está en mantenimiento')).toBeVisible()
    await expect(page.getByText('7:00 a. m. – 9:00 p. m.')).toBeVisible()
  })

  test('[ADM-05] horas reservadas + bloqueadas + libres = total', async ({ page, demo }) => {
    await demo(admin())
    await page.goto('/admin')
    await expect(page.locator('[aria-busy="false"] [title]').first()).toBeVisible()
    await page.waitForTimeout(2500) // contadores animados
    const n = async (t) => parseInt(await page.getByText(t, { exact: true }).locator('xpath=following-sibling::p').innerText())
    const [r, b, l, o] = [await n('Horas reservadas'), await n('Horas bloqueadas'), await n('Horas libres'), await n('Ocupación')]
    expect(r + b + l).toBe(12 * 7) // la primera cancha, de 6 a 18
    expect(o).toBe(Math.round(((r + b) / (r + b + l)) * 100))
  })

  test('[ADM-06][ADM-07] solo lectura y límites de semanas', async ({ page, demo }) => {
    await demo(admin())
    await page.goto('/admin')
    await expect(page.locator('[aria-busy="false"]').first()).toBeAttached()
    expect(await page.locator('[aria-busy] button:not([disabled])').count()).toBe(0)
    const prev = page.getByRole('button', { name: 'Semana anterior' }), next = page.getByRole('button', { name: 'Semana siguiente' })
    for (let i = 0; i < 8; i++) await prev.click()
    await expect(prev).toBeDisabled()
    await page.getByRole('button', { name: 'Ir a la semana actual' }).click()
    for (let i = 0; i < 4; i++) await next.click()
    await expect(next).toBeDisabled()
  })

  test('[ADM-08] cambiar rápido no mezcla datos', async ({ page, demo }) => {
    await demo(admin({ state: estado({ blocks: [{ id: 'b', spaceId: ID.tenis1, date: MANANA, startHour: 6, endHour: 18, reason: 'x', type: 'EVENT' }] }) }))
    await page.goto('/admin')
    for (const c of ['Cancha de tenis 1', 'Cancha fútbol 11', 'Cancha de tenis 1']) await elegir(page, 'Cancha', c)
    await expect(page.locator('[aria-busy="false"]').first()).toBeAttached()
    await expect(columna(page, 2).locator('[title^="Bloqueo institucional · 6:00 a. m.–6:00 p. m."]')).toBeVisible()
  })

  test('[ADM-09] la reserva del estudiante aparece', async ({ page, demo }) => {
    await demo(admin({ state: estado({ reservations: [reserva('res-nueva', { space: ID.multiple1, date: MANANA, hour: 8, hours: 2 })] }) }))
    await page.goto('/admin')
    await elegir(page, 'Cancha', 'Cancha múltiple 1')
    await expect(columna(page, 2).locator('[title="Reserva · 2 h · 8:00 a. m.–10:00 a. m."]')).toBeVisible()
  })
})

test.describe('Espacios', () => {
  const abrir = async (page, demo, extra) => {
    await demo(admin(extra))
    await page.goto('/admin/espacios')
    await expect(fila(page, /múltiple 1/)).toBeVisible()
  }

  test('[ADM-20] buscar', async ({ page, demo }) => {
    await abrir(page, demo)
    const q = page.getByPlaceholder('Cancha…')
    await q.fill('TENIS')
    await expect(page.locator('tbody tr')).toHaveCount(1)
    await q.fill('zzz')
    await expect(page.locator('tbody tr')).toHaveCount(0)
  })

  test('[ADM-20] sin resultados, la lista avisa', async ({ page, demo }) => {
    test.fail(true, 'QA-32: la tabla queda vacía sin mensaje')
    await abrir(page, demo)
    await page.getByPlaceholder('Cancha…').fill('zzz')
    await expect(page.locator('tbody tr')).toHaveCount(0)
    await expect(page.locator('main')).toContainText(/sin resultados|no (hay|encontramos)/i, { timeout: 2000 })
  })

  test('[ADM-21][ADM-22][ADM-23] crear', async ({ page, demo }) => {
    await abrir(page, demo)
    await page.getByRole('button', { name: 'Crear espacio' }).click()
    const d = dialogo(page), ok = d.getByRole('button', { name: 'Crear espacio' })
    await expect(ok).toBeDisabled()
    await d.getByPlaceholder('Cancha…').fill('Cancha QA')
    await d.getByText('Voleibol').click()
    await d.locator('input[type=file]').nth(0).setInputFiles(archivo())
    await expect(ok).toBeDisabled()
    await d.locator('input[type=file]').nth(1).setInputFiles(archivo())
    await expect(ok).toBeEnabled()
    await elegir(page, 'Hora de cierre', '6:00 a. m.')
    await expect(d.getByText('Debe ser posterior a la apertura.')).toBeVisible()
    await expect(ok).toBeDisabled()
    await elegir(page, 'Hora de cierre', '8:00 p. m.')
    await ok.click()
    await expect(page.getByText('Espacio creado')).toBeVisible()
    await expect(fila(page, /Cancha QA/)).toBeVisible()
    await entrarComo(page, 'student', '/app/disponibilidad')
    await expect(page.getByRole('button', { name: /Cancha QA/ })).toBeVisible()
  })

  test('[ADM-24][ADM-25] mantenimiento y vuelta', async ({ page, demo }) => {
    await abrir(page, demo)
    for (const [estadoNuevo, n] of [['Mantenimiento', 0], ['Activo', 1]]) {
      await entrarComo(page, 'admin', '/admin/espacios')
      await fila(page, /tenis 1/).getByRole('button', { name: 'Editar' }).click()
      await elegir(page, 'Estado', estadoNuevo)
      await dialogo(page).getByRole('button', { name: 'Guardar cambios' }).click()
      await expect(page.getByText('Espacio actualizado').first()).toBeVisible()
      await entrarComo(page, 'student', '/app/disponibilidad')
      await expect(page.getByText('múltiple 1').first()).toBeVisible()
      await expect(page.getByRole('button', { name: /tenis 1.*Ver horario/ })).toHaveCount(n)
    }
  })

  test('[ADM-26] el horario cambia el calendario', async ({ page, demo }) => {
    await abrir(page, demo)
    await fila(page, /múltiple 1/).getByRole('button', { name: 'Editar' }).click()
    await elegir(page, 'Hora de cierre', '10:00 a. m.')
    await dialogo(page).getByRole('button', { name: 'Guardar cambios' }).click()
    await expect(page.getByText('Espacio actualizado')).toBeVisible()
    await entrarComo(page, 'student', '/app/inicio')
    await abrirCancha(page)
    await expect(columna(page, 1).locator('button')).toHaveCount(2)
  })

  test('[ADM-28][ADM-29][ADM-30][ADM-31] aforo, nombres y cancelar', async ({ page, demo }) => {
    await abrir(page, demo)
    await fila(page, /tenis 1/).getByRole('button', { name: 'Editar' }).click()
    const d = dialogo(page), ok = d.getByRole('button', { name: 'Guardar cambios' })
    const aforo = d.getByLabel(/Aforo/)
    for (const [v, e] of [['0', '1'], ['999', '500'], ['-3', '1']]) {
      await aforo.fill(v)
      await aforo.blur()
      await expect(aforo).toHaveValue(e)
    }
    const nombre = d.getByPlaceholder('Cancha…')
    await nombre.fill('   ')
    await expect(ok).toBeDisabled()
    await nombre.fill('<b>x</b>')
    await d.getByText('Tenis de campo').click()
    await expect(ok).toBeDisabled()
    await page.keyboard.press('Escape')
    await expect(d).toBeHidden()
    expect((await leerEstado(page)).spaces.find((s) => s.id === ID.tenis1).name).toBe('Cancha de tenis 1')
  })

  test('[ADM-29][TRX-40] HTML y nombres largos no rompen la página', async ({ page, demo }) => {
    const state = estado()
    state.spaces[0].name = '<img src=x onerror=alert(1)>'
    state.spaces[1].name = 'Cancha '.repeat(40)
    page.on('dialog', () => { throw new Error('se ejecutó HTML') })
    await demo(admin({ state }))
    await page.goto('/admin/espacios')
    await expect(page.getByText('<img src=x').locator('visible=true')).toBeVisible()
    expect(await page.evaluate(() => document.documentElement.scrollWidth - innerWidth)).toBeLessThanOrEqual(0)
  })

  test('[PAN-22][PAN-23][PAN-24] panoramas inválidos', async ({ page, demo }) => {
    await abrir(page, demo)
    await fila(page, /tenis 1/).getByRole('button', { name: 'Editar' }).click()
    const input = dialogo(page).locator('input[type=file]').nth(1)
    for (const f of [archivo(Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"/>'), 'a.svg', 'image/svg+xml'), archivo(Buffer.from('hola'), 'a.jpg', 'image/jpeg'), archivo(png(200, 100).subarray(0, 60))]) {
      await input.setInputFiles(f)
      await expect(page.getByText('Panorama no válido').last()).toBeVisible()
    }
    await input.setInputFiles(archivo(Buffer.alloc(31 * 1024 * 1024)))
    await expect(page.getByText('Imagen demasiado grande')).toBeVisible()
  })

  test('[PAN-21][PAN-26] acepta otra proporción; al recargar vuelve la de demo', async ({ page, demo }) => {
    await abrir(page, demo)
    await fila(page, /tenis 1/).getByRole('button', { name: 'Editar' }).click()
    await dialogo(page).locator('input[type=file]').nth(1).setInputFiles(archivo(png(90, 160)))
    await dialogo(page).getByRole('button', { name: 'Guardar cambios' }).click()
    await expect(page.getByText('Espacio actualizado')).toBeVisible()
    await page.reload()
    await fila(page, /tenis 1/).getByRole('button', { name: 'Ver 360°' }).click()
    await expect(page.getByText('Panorama no disponible')).toBeVisible()
  })

  test('[ADM-33][PAN-07] ver 360° sin archivo explica cuál falta', async ({ page, demo }) => {
    await abrir(page, demo)
    await fila(page, /fútbol 5/).filter({ hasText: 'Mantenimiento' }).getByRole('button', { name: 'Ver 360°' }).click()
    await expect(page.getByText('futbol-5.png')).toBeVisible()
  })
})

test.describe('Implementos', () => {
  const abrir = async (page, demo, extra) => {
    await demo(admin(extra))
    await page.goto('/admin/espacios/implementos')
    await expect(fila(page, /Petos/)).toBeVisible()
  }

  test('[ADM-40][ADM-41][ADM-45] crear, duplicado y vacío', async ({ page, demo }) => {
    await abrir(page, demo)
    for (const [nombre, texto] of [['Conos', 'Implemento creado'], ['PETOS', 'Ya existe otro implemento']]) {
      await page.getByRole('button', { name: 'Agregar implemento' }).click()
      await expect(dialogo(page).getByRole('button', { name: 'Agregar' })).toBeDisabled()
      await dialogo(page).getByPlaceholder('Balón de voleibol').fill(nombre)
      await dialogo(page).getByRole('button', { name: 'Agregar' }).click()
      await expect(page.getByText(texto)).toBeVisible()
      if (await dialogo(page).isVisible()) await page.keyboard.press('Escape')
      await expect(dialogo(page)).toBeHidden()
    }
  })

  test('[ADM-42][ADM-44] inactivo no se ofrece', async ({ page, demo }) => {
    await abrir(page, demo)
    await fila(page, /Petos/).getByRole('button', { name: 'Editar' }).click()
    await elegir(page, 'Estado', 'Inactivo')
    await dialogo(page).getByRole('button', { name: 'Guardar cambios' }).click()
    await expect(fila(page, /Petos/)).toContainText('Inactivo')
    await entrarComo(page, 'student', '/app/inicio')
    await abrirCancha(page)
    await libres(page, 1).first().click()
    await page.getByRole('button', { name: /^Continuar/ }).locator('visible=true').click()
    await expect(page.getByText('Balón de baloncesto')).toBeVisible()
    await expect(page.getByText('Petos')).toHaveCount(0)
  })

  test('[ADM-43] stock por debajo de lo comprometido', async ({ page, demo }) => {
    await abrir(page, demo, { state: estado({ reservations: [reserva('a', { date: MANANA, hour: 9, equipment: [{ equipmentId: 'eq-petos', quantity: 5 }] })] }) })
    await fila(page, /Petos/).getByRole('button', { name: 'Editar' }).click()
    const campo = dialogo(page).getByLabel(/Stock/)
    await campo.fill('4')
    await dialogo(page).getByRole('button', { name: 'Guardar cambios' }).click()
    await expect(page.getByText(/no puede ser menor a 5/)).toBeVisible()
    await campo.fill('5')
    await dialogo(page).getByRole('button', { name: 'Guardar cambios' }).click()
    await expect(page.getByText('Implemento actualizado')).toBeVisible()
  })
})

test.describe('Bloqueos', () => {
  const abrir = async (page, demo, extra) => {
    await demo(admin(extra))
    await page.goto('/admin/bloqueos')
    await elegir(page, 'Espacio', 'Cancha múltiple 1')
  }
  const motivo = (page) => page.getByPlaceholder('Clase de voleibol')
  const ok = (page) => page.getByRole('button', { name: 'Confirmar bloqueo' })
  const franja = async (page, date, desde, hasta) => {
    await page.locator('#block-date').fill(date)
    await elegir(page, 'Hora de inicio', desde)
    await elegir(page, 'Hora de fin', hasta)
  }

  test('[ADM-50][ADM-51][ADM-61][DIS-15] puntual, motivo y lista @movil', async ({ page, demo, isMobile }) => {
    await abrir(page, demo)
    await expect(ok(page)).toBeDisabled()
    await motivo(page).fill('   ')
    await expect(ok(page)).toBeDisabled()
    await motivo(page).fill('Torneo QA')
    await franja(page, MANANA, '10:00 a. m.', '12:00 p. m.')
    await ok(page).click()
    await expect(page.getByText('2 franja(s) bloqueadas.')).toBeVisible()
    await expect(page.getByText('Creados en esta sesión')).toBeVisible()
    await page.goto('/admin/bloqueos')
    await expect(titulo(page, 'Bloquear franjas')).toBeVisible()
    await expect(page.getByText('Creados en esta sesión')).toHaveCount(0)
    if (isMobile) return
    await entrarComo(page, 'student', '/app/inicio')
    await abrirCancha(page)
    await expect(columna(page, 1).locator('[title^="Torneo QA"]')).toBeVisible()
  })

  test('[ADM-52] cancela la reserva del estudiante y libera la cuota', async ({ page, demo }) => {
    await abrir(page, demo, { state: estado({ reservations: [reserva('a', { date: MANANA, hour: 10 })] }) })
    await motivo(page).fill('Clase')
    await franja(page, MANANA, '10:00 a. m.', '11:00 a. m.')
    await ok(page).click()
    await expect(page.getByText('1 reserva(s) cancelada(s)')).toBeVisible()
    await entrarComo(page, 'student', '/app/mis-reservas')
    await page.getByRole('tab', { name: 'Historial (1)' }).click()
    await expect(page.getByText('Cancelada por administrador')).toBeVisible()
    await page.goto('/app/inicio')
    await expect(page.getByText('4 h disponibles')).toBeVisible()
  })

  test('[ADM-53] con reserva en uso no crea nada', async ({ page, demo }) => {
    await abrir(page, demo, { state: estado({ reservations: [reserva('a', { hour: 10, status: 'IN_USE' })] }) })
    await motivo(page).fill('Clase')
    await franja(page, HOY, '10:00 a. m.', '11:00 a. m.')
    await ok(page).click()
    await expect(page.getByText(/reserva en curso; no se creó/)).toBeVisible()
    expect((await leerEstado(page)).blocks).toHaveLength(0)
  })

  const recurrente = async (page, dias, hasta) => {
    await motivo(page).fill('Grupo')
    await page.getByRole('button', { name: 'Fijo / recurrente' }).click()
    for (const d of dias) await page.getByRole('button', { name: d, exact: true }).click()
    if (hasta) await page.locator('#block-until').fill(hasta)
  }
  test('[ADM-54][ADM-55] recurrente y sus validaciones', async ({ page, demo }) => {
    await abrir(page, demo)
    await franja(page, MANANA, '8:00 a. m.', '10:00 a. m.')
    await recurrente(page, [])
    await expect(ok(page)).toBeDisabled()
    await page.getByRole('button', { name: 'Lun', exact: true }).click()
    await page.getByRole('button', { name: 'Mié', exact: true }).click()
    await page.locator('#block-until').fill('2026-11-20')
    await expect(ok(page)).toBeDisabled()
    await page.locator('#block-until').fill('2026-12-08')
    await ok(page).click()
    await expect(page.getByText('8 franja(s) bloqueadas.')).toBeVisible() // 25/11, 30/11, 2/12 y 7/12, 2 h
  })
  test('[ADM-56] sin fechas coincidentes avisa', async ({ page, demo }) => {
    test.fail(true, 'QA-10')
    await abrir(page, demo)
    await recurrente(page, ['Dom'], '2026-11-25')
    await ok(page).click()
    await expect(page.getByText(/Bloqueo confirmado|No se pudo/)).toBeVisible()
    await expect(page.getByText('Bloqueo confirmado')).toHaveCount(0, { timeout: 500 })
  })
  test('[ADM-57] fecha pasada escrita a mano', async ({ page, demo }) => {
    await abrir(page, demo)
    await motivo(page).fill('x')
    await page.locator('#block-date').fill('2026-11-01')
    await ok(page).click()
    await page.waitForTimeout(800)
    expect((await leerEstado(page)).blocks).toHaveLength(0)
  })
  test('[ADM-59] las horas se ajustan al cambiar de espacio', async ({ page, demo }) => {
    await abrir(page, demo)
    await elegir(page, 'Hora de inicio', '7:00 p. m.')
    await elegir(page, 'Espacio', 'Cancha de tenis 1')
    await expect(page.getByLabel('Hora de inicio').locator('visible=true').first()).toContainText('6:00 a. m.')
  })
})

test.describe('Reglas y QR', () => {
  test('[ADM-70][ADM-71][ADM-72][ADM-73][MIS-51] editar, limitar, descartar y reflejar', async ({ page, demo }) => {
    await demo(admin())
    await page.goto('/admin/reglas')
    const guardar = page.getByRole('button', { name: 'Guardar cambios' }), descartar = page.getByRole('button', { name: 'Descartar' })
    const cuota = page.getByLabel(/Cuota semanal/), faltas = page.getByLabel(/Inasistencias para suspender/)
    await expect(guardar).toBeDisabled()
    await expect(descartar).toBeDisabled()
    for (const [c, v, e] of [[cuota, '0', '1'], [cuota, '999', '168'], [faltas, '0', '1'], [faltas, '99', '31']]) {
      await c.fill(v)
      await c.blur()
      await expect(c).toHaveValue(e)
    }
    await descartar.click()
    await expect(cuota).toHaveValue('4')
    await cuota.fill('6')
    await cuota.blur()
    await guardar.click()
    await expect(page.getByText('Reglas actualizadas')).toBeVisible()
    await entrarComo(page, 'student', '/app/mis-reservas/reglas')
    await expect(page.getByText('6 horas', { exact: true })).toBeVisible()
    await page.goto('/app/inicio')
    await expect(page.getByText('6 h disponibles')).toBeVisible()
  })

  test('[ADM-80][ADM-82] QR por espacio y descarga', async ({ page, demo }) => {
    await demo(admin())
    await page.goto('/admin/espacios/qr')
    const img = page.locator('main img[alt^="Código QR"]')
    await expect(img).toBeVisible()
    const antes = await img.getAttribute('src')
    await elegir(page, 'Espacio', 'Cancha múltiple 2')
    await expect(img).not.toHaveAttribute('src', antes)
    const [descarga] = await Promise.all([page.waitForEvent('download'), page.getByRole('link', { name: 'Descargar SVG' }).click()])
    expect(descarga.suggestedFilename()).toMatch(/\.svg$/)
  })

  test('[ADM-82] el archivo conserva las tildes del nombre de forma legible', async ({ page, demo }) => {
    test.fail(true, 'QA-33: «múltiple» queda como «m-ltiple»')
    await demo(admin())
    await page.goto('/admin/espacios/qr')
    await elegir(page, 'Espacio', 'Cancha múltiple 2')
    await expect(page.locator('a[download]')).toHaveAttribute('download', /m[uú]ltiple/, { timeout: 2000 })
  })

  test('[ADM-81] al imprimir solo salen nombre y QR, en una hoja', async ({ page, demo }) => {
    await demo(admin())
    await page.goto('/admin/espacios/qr')
    await expect(page.locator('main img[alt^="Código QR"]')).toBeVisible()
    await page.emulateMedia({ media: 'print' })
    await expect(page.locator('.print-sheet')).toBeVisible()
    await expect(page.locator('#root')).toBeHidden()
    const pdf = await page.pdf()
    expect(pdf.toString('latin1').match(/\/Type\s*\/Page\b/g)).toHaveLength(1)
  })
})

test('[ACC-42][ACC-43] el administrador ve como estudiante, solo consulta', async ({ page, demo }) => {
  await demo(admin())
  await page.goto('/admin')
  await page.locator('header button').last().click()
  await page.getByRole('menuitem', { name: 'Ver como estudiante' }).click()
  await expect(page).toHaveURL(/app\/inicio/)
  await abrirCancha(page)
  await expect(page.getByText('Vista de consulta')).toBeVisible()
  await expect(celda(page, 1, 10)).toBeDisabled()
  await page.locator('header button').last().click()
  await page.getByRole('menuitem', { name: 'Modo administrador' }).click()
  await expect(page).toHaveURL(/\/admin$/)
})

// Utilidades del backend real: base de datos, correo, sesiones y cliente HTTP.
import { execFileSync } from 'node:child_process'
import { createHmac, randomUUID } from 'node:crypto'
import path from 'node:path'
import { test as base, expect } from '@playwright/test'
import { SEED_PNG } from '../stack/png.mjs'

export { expect }
export const API = 'http://localhost:18080'
export const APP = 'http://localhost:5190'
const MAIL = 'http://localhost:18025/api/v1'
const COMPOSE = path.resolve(import.meta.dirname, '../stack/compose.yaml')
const JWT_SECRET = 'qa-jwt-secret-solo-para-pruebas-0123456789'
export const ADMIN = 'admin.qa@unimagdalena.edu.co'
export const CONTACTO = 'deportes.qa@unimagdalena.edu.co'

export const compose = (...args) =>
  execFileSync('docker', ['compose', '-f', COMPOSE, ...args], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] })
export const sql = (query) => compose('exec', '-T', 'postgres', 'psql', '-U', 'qa', '-d', 'qa', '-v', 'ON_ERROR_STOP=1', '-qtAc', query).trim()

// ------------------------------------------------------------------ datos

export const CANCHA = 'c0000000-0000-4000-8000-000000000001' // baloncesto y voleibol, 0–23
export const TENIS = 'c0000000-0000-4000-8000-000000000002' // 6–18
export const CERRADA = 'c0000000-0000-4000-8000-000000000003' // en mantenimiento
export const BALON = 'e0000000-0000-4000-8000-000000000001'
export const PETOS = 'e0000000-0000-4000-8000-000000000002'
export const MALLA = 'e0000000-0000-4000-8000-000000000003'

const SEED = (() => {
  const image = (n) => `('a0000000-0000-4000-8000-00000000000${n}','image/png','seed/${n}',${SEED_PNG.length})`
  const space = (id, name, open, close, status, a, b) =>
    `('${id}','${name}',20,'Calzado deportivo','${open}','${close}','${status}','a0000000-0000-4000-8000-00000000000${a}','a0000000-0000-4000-8000-00000000000${b}')`
  return `
    INSERT INTO space_image VALUES ${[1, 2, 3, 4, 5, 6].map(image).join(',')};
    INSERT INTO space (id,name,capacity,requirements,opening_time,closing_time,status,preview_image_id,panorama_image_id) VALUES
      ${space(CANCHA, 'Cancha QA', '00:00', '23:00', 'ACTIVE', 1, 2)},
      ${space(TENIS, 'Tenis QA', '06:00', '18:00', 'ACTIVE', 3, 4)},
      ${space(CERRADA, 'Cerrada QA', '06:00', '22:00', 'MAINTENANCE', 5, 6)};
    INSERT INTO space_discipline VALUES ('${CANCHA}','BASKETBALL'),('${CANCHA}','VOLLEYBALL'),('${TENIS}','TENNIS'),('${CERRADA}','FOOTBALL_5');
    INSERT INTO equipment VALUES
      ('${BALON}','Balón de baloncesto','BASKETBALL',10,'AVAILABLE'),
      ('${PETOS}','Petos',NULL,20,'AVAILABLE'),
      ('${MALLA}','Malla de voleibol','VOLLEYBALL',2,'INACTIVE');`
})()

/** Deja la base como recién instalada, con 3 espacios y 3 implementos, y vacía el buzón. */
export const reset = async () => {
  sql(`TRUNCATE monthly_suspension, audit_log, usage_parameters_head, usage_parameters, reservation_equipment, equipment,
       institutional_block, reservation, space_discipline, space, storage_object_cleanup, space_image,
       login_code_request_ip, login_code, app_user CASCADE;
       INSERT INTO usage_parameters VALUES ('00000000-0000-0000-0000-000000000001',1,4,3,now(),NULL);
       INSERT INTO usage_parameters_head VALUES (1,'00000000-0000-0000-0000-000000000001');${SEED}`)
  await fetch(`${MAIL}/messages`, { method: 'DELETE' })
}

/** Inserta una reserva con el minuto exacto que haga falta. Devuelve su id. */
export const reserva = (email, { minutes, hours = 1, status = 'CONFIRMED', space = CANCHA, created } = {}) => {
  const id = randomUUID()
  sql(`INSERT INTO reservation (id,user_id,space_id,start_at,end_at,status,created_at,checked_in_at,cancellation_threshold_minutes,checkin_opening_minutes)
       SELECT '${id}',id,'${space}',now()+interval '${minutes} min',now()+interval '${minutes + hours * 60} min','${status}',
       ${created ?? "now()-interval '1 day'"},${status === 'IN_USE' ? 'now()' : 'NULL'},60,10 FROM app_user WHERE email='${email}'`)
  return id
}
export const estadoDe = (id) => sql(`SELECT status FROM reservation WHERE id='${id}'`)

// ------------------------------------------------------------------ fechas (Bogotá)

export const dia = (n = 0) => new Date(Date.now() - 5 * 3_600_000 + n * 86_400_000).toISOString().slice(0, 10)
export const instante = (date, hour) => `${date}T${String(hour).padStart(2, '0')}:00:00-05:00`

// ------------------------------------------------------------------ correo

const list = async (to) => (await (await fetch(`${MAIL}/search?query=${encodeURIComponent(`to:${to}`)}`)).json()).messages
/** Espera el correo más reciente para `to` cuyo asunto o comienzo cumpla `pattern`. */
export const correo = async (to, pattern = /./) => {
  let found
  await expect
    .poll(async () => (found = (await list(to)).find((m) => pattern.test(`${m.Subject} ${m.Snippet}`))) != null, { message: `correo ${pattern} para ${to}`, timeout: 15_000 })
    .toBe(true)
  return (await fetch(`${MAIL}/message/${found.ID}`)).json()
}
export const correos = list
export const codigo = async (to) => /\b(\d{6})\b/.exec((await correo(to, /c[oó]digo/i)).Text)[1]

// ------------------------------------------------------------------ sesiones

export const jwt = (payload, { secret = JWT_SECRET, header = { alg: 'HS256', typ: 'JWT' } } = {}) => {
  const b64 = (v) => Buffer.from(typeof v === 'string' ? v : JSON.stringify(v)).toString('base64url')
  const body = `${b64(header)}.${b64(payload)}`
  return `${body}.${header.alg === 'none' ? '' : createHmac('sha256', secret).update(body).digest('base64url')}`
}
const claims = (email, extra = {}) => {
  const now = Math.floor(Date.now() / 1000)
  const [id, role] = sql(`SELECT id,role FROM app_user WHERE email='${email}'`).split('|')
  return { sub: id, email, role, iat: now, exp: now + 3600, ...extra }
}
/** Token propio: vencido, reautenticado o alterado, según `extra`. */
export const tokenDe = (email, extra, opts) => jwt(claims(email, extra), opts)
export const reautenticado = (email = ADMIN) => tokenDe(email, { reauth_at: Math.floor(Date.now() / 1000) })

export const login = async (email, name = 'Persona QA') => {
  const res = await fetch(`${API}/dev/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, name }),
  })
  return (await res.json()).token
}

export const cliente = (token) => async (method, url, body) => {
  const form = body instanceof FormData
  const res = await fetch(API + url, {
    method,
    headers: { ...(token && { Authorization: `Bearer ${token}` }), ...(body !== undefined && !form && { 'Content-Type': 'application/json' }) },
    body: body === undefined || form ? body : typeof body === 'string' ? body : JSON.stringify(body),
  })
  const text = await res.text()
  let json = null
  try { json = JSON.parse(text) } catch { /* binario o vacío */ }
  return { status: res.status, body: json, text, code: json?.code, headers: res.headers }
}

export const ANA = 'ana.qa@unimagdalena.edu.co'
export const LUIS = 'luis.qa@unimagdalena.edu.co'

export const test = base.extend({
  limpio: [async ({}, use) => { await reset(); await use() }, { auto: true }],
  ana: async ({ limpio }, use) => { void limpio; await use(cliente(await login(ANA, 'Ana QA'))) },
  luis: async ({ limpio }, use) => { void limpio; await use(cliente(await login(LUIS, 'Luis QA'))) },
  admin: async ({ limpio }, use) => { void limpio; await login(ADMIN, 'Admin QA'); await use(cliente(reautenticado())) },
  /** Página del navegador con sesión real ya iniciada. */
  sesion: async ({ browser }, use) => {
    const contexts = []
    await use(async (token, options = {}) => {
      const context = await browser.newContext({
        baseURL: APP, locale: 'es-CO', timezoneId: 'America/Bogota', ...options,
        storageState: { cookies: [], origins: [{ origin: APP, localStorage: [{ name: 'ud-token', value: token }] }] },
      })
      contexts.push(context)
      return context.newPage()
    })
    await Promise.all(contexts.map((c) => c.close()))
  },
})

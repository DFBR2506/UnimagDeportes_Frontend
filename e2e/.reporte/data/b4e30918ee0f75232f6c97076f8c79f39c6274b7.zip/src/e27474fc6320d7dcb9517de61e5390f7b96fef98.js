import AxeBuilder from '@axe-core/playwright'
import { HOY, ID, MANANA, abrirCancha, dialogo, estado, expect, leerEstado, libres, reserva, test, titulo } from '../support/demo.js'
import { png } from '../stack/png.mjs'

const PANTALLAS = {
  null: ['/bienvenida', '/acceso', '/acceso/no-permitido'],
  student: ['/app/inicio', '/app/disponibilidad', `/app/disponibilidad/${ID.multiple1}`, '/app/mis-reservas', '/app/mis-reservas/cuota', '/app/mis-reservas/reglas', '/app/mis-reservas/cancelar/r', `/checkin/${ID.multiple1}`, '/app/conflicto'],
  admin: ['/admin', '/admin/espacios', '/admin/espacios/implementos', '/admin/espacios/qr', '/admin/bloqueos', '/admin/reglas'],
}
const conReserva = () => estado({ reservations: [reserva('r', { date: MANANA, hour: 9 })] })
const asentar = (page) => page.waitForTimeout(2200) // animaciones de entrada

test.describe('Diseño', () => {
  for (const width of [320, 390, 767, 768, 1023, 1024, 1280]) {
    test(`[TRX-01][TRX-03] ${width} px: sin desborde y con un solo menú`, async ({ page, demo }) => {
      test.setTimeout(120_000)
      await page.setViewportSize({ width, height: 800 })
      await demo({ role: null, state: conReserva() })
      for (const [role, paths] of Object.entries(PANTALLAS)) {
        await page.goto('/bienvenida')
        await page.evaluate((r) => (r === 'null' ? localStorage.removeItem('ud-token') : localStorage.setItem('ud-token', `demo:${r}`)), role)
        for (const path of paths) {
          await page.goto(path)
          await page.waitForTimeout(900)
          expect(await page.evaluate(() => document.documentElement.scrollWidth - innerWidth), `${path} a ${width}`).toBeLessThanOrEqual(0)
          if (role !== 'null') await expect(page.getByRole('navigation', { name: 'Principal' }).locator('visible=true'), path).toHaveCount(1)
        }
      }
    })
  }

  test('[TRX-02] la barra inferior no tapa el final de la página', async ({ page, demo }) => {
    await page.setViewportSize({ width: 390, height: 800 })
    await demo({ state: conReserva() })
    for (const path of PANTALLAS.student) {
      await page.goto(path)
      await asentar(page)
      const solape = () => page.evaluate(() => {
        scrollTo(0, document.body.scrollHeight)
        const barra = [...document.querySelectorAll('nav[aria-label="Principal"]')].find((n) => getComputedStyle(n).position === 'fixed').getBoundingClientRect().top
        const items = [...document.querySelectorAll('main a, main button, main p')].filter((e) => e.offsetParent)
        const ultimo = items.reduce((a, e) => (e.getBoundingClientRect().bottom > a.getBoundingClientRect().bottom ? e : a))
        return { tapado: Math.max(0, Math.floor(ultimo.getBoundingClientRect().bottom - barra)), cual: ultimo.textContent.slice(0, 60) }
      })
      await expect.poll(solape, { message: path }).toMatchObject({ tapado: 0 })
    }
  })

  test('[TRX-04] al cambiar de sección en móvil abre arriba @movil', async ({ page, demo }) => {
    await page.setViewportSize({ width: 390, height: 700 })
    await demo()
    await page.goto('/app/mis-reservas/reglas')
    await asentar(page)
    await page.evaluate(() => scrollTo(0, 500))
    await page.getByRole('button', { name: 'Canchas' }).click()
    await expect(titulo(page, 'Disponibilidad')).toBeVisible()
    await expect.poll(() => page.evaluate(() => scrollY)).toBe(0)
  })

  test('[DIS-38][DIS-39][DIS-40] calendario táctil @movil', async ({ page, demo, isMobile }) => {
    test.skip(!isMobile, 'solo con pantalla táctil')
    await demo()
    await abrirCancha(page)
    await expect(page.locator('[aria-busy] > div.border-l').locator('visible=true')).toHaveCount(1)
    await page.getByRole('button', { name: /Miércoles, 25/ }).tap()
    const cell = page.locator('[aria-busy] button:not([disabled])').locator('visible=true').first()
    await cell.scrollIntoViewIfNeeded()
    const box = await cell.boundingBox()
    const cdp = await page.context().newCDPSession(page)
    const y0 = await page.evaluate(() => scrollY)
    const dedo = (type, dy) => cdp.send('Input.dispatchTouchEvent', { type, touchPoints: dy == null ? [] : [{ x: Math.round(box.x + 40), y: Math.round(box.y + 20 + dy) }] })
    await dedo('touchStart', 0)
    for (let i = 1; i <= 10; i++) await dedo('touchMove', -20 * i)
    await dedo('touchEnd')
    await expect.poll(() => page.evaluate(() => scrollY)).not.toBe(y0)
    await page.waitForTimeout(600)
    await expect(page.getByText('Franja seleccionada').locator('visible=true')).toHaveCount(0)
    await cell.tap()
    const seguir = page.getByRole('button', { name: /^Continuar/ }).locator('visible=true')
    await expect(seguir).toBeInViewport()
    await seguir.tap()
    await expect(titulo(page, 'Confirma tu reserva')).toBeVisible()
  })

  test('[TRX-08] cambiar de sección muy rápido no deja pantallas en blanco', async ({ page, demo, errores }) => {
    await demo()
    await page.goto('/app/inicio')
    for (let i = 0; i < 12; i++) await page.getByRole('navigation', { name: 'Principal' }).locator('visible=true').getByRole('button').nth(i % 3).click({ force: true })
    await expect(titulo(page, 'Mis reservas')).toBeVisible()
    expect(errores).toEqual([])
  })

  test('[QA-30] lo escrito durante la transición no se pierde', async ({ page }) => {
    test.fail(true, 'QA-30: la pantalla entrante se monta dos veces')
    await page.goto('/bienvenida')
    await asentar(page)
    await page.getByRole('button', { name: 'Iniciar sesión' }).click()
    await page.waitForTimeout(150)
    await page.keyboard.type('maria', { delay: 20 })
    await page.waitForTimeout(1500)
    await expect(page.getByLabel('Correo institucional')).toHaveValue('maria', { timeout: 500 })
  })
})

test.describe('Accesibilidad', () => {
  // Contraste aparte (QA-11): así cualquier otra infracción sí hace fallar la prueba.
  for (const [role, paths] of Object.entries(PANTALLAS)) {
    for (const path of paths) {
      test(`[TRX-23] axe ${path.replace(ID.multiple1, ':cancha')}`, async ({ page, demo }) => {
        await demo({ role: role === 'null' ? null : role, state: conReserva() })
        await page.goto(path)
        await asentar(page)
        const { violations } = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa']).disableRules(['color-contrast']).analyze()
        expect(violations.map((v) => `${v.id}: ${v.nodes[0].target}`)).toEqual([])
      })
    }
  }
  for (const path of [`/app/disponibilidad/${ID.multiple1}`, '/admin']) {
    test(`[TRX-23] contraste en ${path.replace(ID.multiple1, ':cancha')}`, async ({ page, demo }) => {
      test.fail(true, 'QA-11')
      await demo({ role: path.startsWith('/admin') ? 'admin' : 'student', time: null })
      await page.goto(path)
      await page.waitForTimeout(3500)
      const { violations } = await new AxeBuilder({ page }).withRules(['color-contrast']).analyze()
      expect(violations).toEqual([])
    })
  }

  test('[TRX-21] diálogos: foco dentro y Esc devuelve el foco', async ({ page, demo }) => {
    await demo({ role: 'admin' })
    await page.goto('/admin/espacios')
    await asentar(page)
    const abrir = page.getByRole('button', { name: 'Crear espacio' })
    await abrir.click()
    const d = dialogo(page)
    await expect(d).toBeVisible()
    for (let i = 0; i < 40; i++) {
      await page.keyboard.press('Tab')
      expect(await d.evaluate((el) => el.contains(document.activeElement) || document.activeElement === document.body || document.activeElement.hasAttribute('data-base-ui-focus-guard'))).toBe(true)
    }
    await page.keyboard.press('Escape')
    await expect(d).toBeHidden()
    await expect(abrir).toBeFocused()
  })

  test('[TRX-25] «reducir movimiento» detiene las animaciones decorativas', async ({ page }) => {
    test.fail(true, 'QA-31: solo el visor 360° lo respeta')
    await page.emulateMedia({ reducedMotion: 'reduce' })
    await page.goto('/bienvenida')
    await asentar(page)
    const pos = () => page.locator('.blur-3xl').first().evaluate((e) => getComputedStyle(e).transform)
    const a = await pos()
    await page.waitForTimeout(1000)
    expect(await pos()).toBe(a)
  })

  test('[TRX-20] los botones de cantidad se anuncian en español', async ({ page, demo }) => {
    test.fail(true, 'QA-34: dicen «Increment» y «Decrement»')
    await demo({ role: 'admin' })
    await page.goto('/admin/reglas')
    await expect(page.getByLabel(/Cuota semanal/)).toBeVisible()
    await expect(page.getByRole('button', { name: 'Increment' })).toHaveCount(0, { timeout: 1000 })
  })
})

test.describe('Contacto', () => {
  test('[TRX-30][TRX-31][TRX-32][TRX-34] abrir, validar y enviar @movil', async ({ page, demo, isMobile }) => {
    await demo()
    await page.goto('/app/inicio')
    await page.getByRole('button', { name: isMobile ? 'Contacto' : 'Contactar al administrador', exact: true }).click()
    const d = dialogo(page), enviar = d.getByRole('button', { name: 'Enviar mensaje' })
    await d.getByLabel('Mensaje').fill('   ')
    await expect(enviar).toBeDisabled()
    await d.getByLabel('Mensaje').fill('<script>alert(1)</script>')
    await enviar.click()
    await expect(page.getByText('Mensaje enviado')).toBeVisible()
    await expect(d).toBeHidden()
  })

  test('[TRX-33] el enlace del correo abre el formulario y recargar no lo reabre', async ({ page, demo }) => {
    await demo()
    await page.goto('/app/contacto')
    await expect(dialogo(page)).toBeVisible()
    await page.reload()
    await expect(titulo(page, /Hola/)).toBeVisible()
    await expect(dialogo(page)).toHaveCount(0)
  })

  test('[TRX-34] cerrar sin enviar conserva el borrador', async ({ page, demo }) => {
    test.fail(true, 'QA-12')
    await demo()
    await page.goto('/app/contacto')
    await page.getByLabel('Mensaje').fill('borrador')
    await page.keyboard.press('Escape')
    await expect(dialogo(page)).toBeHidden()
    await page.getByRole('button', { name: 'Contactar al administrador' }).click()
    await expect(page.getByLabel('Mensaje')).toHaveValue('borrador', { timeout: 1500 })
  })
})

test.describe('Robustez', () => {
  test('[TRX-44] los accesos de demostración no salen en producción', async ({ page }) => {
    test.fail(true, 'QA-14: este es el build de producción y aparecen')
    await page.goto('/bienvenida')
    await asentar(page)
    await expect(page.getByText('Entrar como administrador')).toHaveCount(0, { timeout: 1000 })
  })

  test('[TRX-51] con red lenta siempre hay indicador de carga', async ({ page, demo }) => {
    await demo({ role: null })
    await page.addInitScript(() => localStorage.setItem('ud-token', 'real'))
    await page.route('**/api/**', () => {}) // nunca responde
    await page.goto('/app/inicio')
    await expect(page.getByLabel('Cargando tu sesión')).toBeVisible()
  })

  test('[TRX-52] sin Local Storage la demo funciona en memoria', async ({ page }) => {
    await page.addInitScript(() => {
      for (const m of ['getItem', 'setItem', 'removeItem']) Storage.prototype[m] = () => { throw new Error('bloqueado') }
    })
    await page.goto('/bienvenida')
    await page.getByRole('button', { name: 'Entrar como estudiante' }).click()
    await expect(titulo(page, 'Hola, María')).toBeVisible()
  })

  test('[TRX-53] datos dañados se recuperan', async ({ page }) => {
    await page.addInitScript(() => { localStorage.setItem('ud-token', 'demo:student'); localStorage.setItem('ud-demo-state-v1', '{roto') })
    await page.goto('/app/mis-reservas')
    await expect(page.getByRole('tab', { name: /Próximas/ })).toBeVisible()
  })

  test('[TRX-54] dos pestañas no se pisan los datos', async ({ page, demo, context }) => {
    test.fail(true, 'QA-35: cada pestaña guarda su copia completa')
    await demo()
    await page.goto('/app/inicio')
    await expect(titulo(page, /Hola/)).toBeVisible()
    const otra = await context.newPage()
    await otra.addInitScript(() => { Math.random = () => 0.9 })
    await otra.clock.setFixedTime(new Date(`${HOY}T10:30:00-05:00`))
    await abrirCancha(otra)
    await abrirCancha(page)
    const dentro = async (p, day) => {
      await libres(p, day).first().click()
      await p.getByRole('button', { name: /^Continuar/ }).locator('visible=true').click()
      await p.getByRole('button', { name: 'Confirmar reserva' }).click()
      await expect(titulo(p, 'Reserva confirmada')).toBeVisible()
    }
    await dentro(otra, 1)
    await dentro(page, 2)
    expect((await leerEstado(page)).reservations).toHaveLength(2)
  })

  test('[TRX-56] las rutas internas abren directo', async ({ page, demo }) => {
    await demo()
    const res = await page.goto('/app/mis-reservas/cuota')
    expect(res.status()).toBe(200)
    await expect(titulo(page, 'Mi cuota semanal')).toBeVisible()
  })

  test('[ACC-53] el paquete publicado no contiene secretos', async ({ page }) => {
    const textos = []
    page.on('response', async (r) => /\.js$/.test(r.url()) && textos.push(await r.text().catch(() => '')))
    await page.goto('/bienvenida', { waitUntil: 'networkidle' })
    expect(textos.join('')).not.toMatch(/sb_secret_|service_role|BEGIN (RSA|PRIVATE)|SECRET-KEY/) // [TRX-45]
  })
})

test.describe('Panorama 360° @webgl', () => {
  // Foto pequeña en vez de los 20 MB reales: aquí se prueba el visor, no la descarga
  const conFoto = async (page, body = png(512, 256)) => page.route('**/panoramas/multiple-1.png', (r) => r.fulfill({ contentType: 'image/png', body }))
  const brujula = (page) => page.getByLabel(/Orientación relativa/)
  const listo = (page) => expect(page.getByText('Vista 360°', { exact: true })).toBeVisible({ timeout: 25_000 })

  test('[PAN-01][PAN-02][PAN-03] carga, botones y flechas', async ({ page, demo, errores }) => {
    test.setTimeout(90_000)
    await conFoto(page)
    await demo({ time: null })
    await page.goto(`/app/disponibilidad/${ID.multiple1}`)
    await listo(page)
    await page.getByRole('button', { name: 'Pausar giro' }).click()
    const a = await brujula(page).getAttribute('aria-label')
    await page.getByRole('button', { name: 'Girar a la derecha' }).click()
    await expect(brujula(page)).not.toHaveAttribute('aria-label', a)
    const b = await brujula(page).getAttribute('aria-label')
    const y = await page.evaluate(() => scrollY)
    await page.getByRole('region', { name: /Panorama de/ }).focus()
    await page.keyboard.press('ArrowRight')
    await expect(brujula(page)).not.toHaveAttribute('aria-label', b)
    expect(await page.evaluate(() => scrollY)).toBe(y)
    await page.getByRole('button', { name: 'Acercar' }).click()
    expect(errores.filter((e) => !/GL Driver|GPU stall/.test(e))).toEqual([])
  })

  test('[PAN-06] pantalla completa', async ({ page, demo }) => {
    test.setTimeout(90_000)
    await conFoto(page)
    await demo({ time: null })
    await page.goto(`/app/disponibilidad/${ID.multiple1}`)
    await listo(page)
    await page.getByRole('button', { name: 'Pantalla completa' }).click()
    await expect.poll(() => page.evaluate(() => Boolean(document.fullscreenElement))).toBe(true)
    await page.getByRole('button', { name: 'Pantalla completa' }).click()
    await expect.poll(() => page.evaluate(() => Boolean(document.fullscreenElement))).toBe(false)
  })

  test('[PAN-08] reintentar cuando aparece el archivo', async ({ page, demo }) => {
    test.setTimeout(90_000)
    await demo({ time: null })
    await page.goto(`/app/disponibilidad/${ID.tenis1}`)
    await expect(page.getByText('Panorama no disponible')).toBeVisible()
    await page.route('**/panoramas/tenis-1.jpg', (r) => r.fulfill({ contentType: 'image/png', body: png(512, 256) }))
    await page.getByRole('button', { name: 'Volver a intentar' }).click()
    await listo(page)
  })

  test('[PAN-10] reducir movimiento: no gira solo', async ({ page, demo }) => {
    test.setTimeout(90_000)
    await page.emulateMedia({ reducedMotion: 'reduce' })
    await conFoto(page)
    await demo({ time: null })
    await page.goto(`/app/disponibilidad/${ID.multiple1}`)
    await listo(page)
    const a = await brujula(page).getAttribute('aria-label')
    await page.waitForTimeout(2500)
    await expect(brujula(page)).toHaveAttribute('aria-label', a)
    await expect(page.getByRole('button', { name: 'Reanudar giro' })).toBeVisible()
  })

  test('[PAN-12] pérdida de WebGL y recuperación', async ({ page, demo }) => {
    test.setTimeout(90_000)
    await conFoto(page)
    await demo({ time: null })
    await page.goto(`/app/disponibilidad/${ID.multiple1}`)
    await listo(page)
    await page.locator('[aria-label^="Panorama"] canvas').evaluate((c) => c.getContext('webgl2').getExtension('WEBGL_lose_context').loseContext())
    await expect(page.getByText('No se pudo mostrar el panorama')).toBeVisible()
    await page.getByRole('button', { name: 'Volver a intentar' }).click()
    await listo(page)
  })

  test('[PAN-01] la foto real de 20 MB también se muestra', async ({ page, demo }) => {
    test.setTimeout(120_000)
    await demo({ time: null })
    await page.goto(`/app/disponibilidad/${ID.multiple1}`)
    await expect(page.getByText('Vista 360°', { exact: true })).toBeVisible({ timeout: 90_000 })
  })
})

test('[PAN-09] cambiar rápido de cancha no muestra la foto de otra', async ({ page, demo }) => {
  await page.route('**/panoramas/multiple-1.png', async (r) => { await new Promise((f) => setTimeout(f, 1500)); await r.fulfill({ contentType: 'image/png', body: png(64, 32) }).catch(() => {}) })
  await demo({ time: null })
  await page.goto(`/app/disponibilidad/${ID.multiple1}`)
  await page.getByRole('button', { name: 'Todas las canchas' }).click()
  await page.getByRole('button', { name: /tenis 1/ }).click()
  await expect(page.getByText('tenis-1.png')).toBeVisible()
  await page.waitForTimeout(2000)
  await expect(page.getByText('tenis-1.png')).toBeVisible()
})

test('[PAN-11] sin WebGL: alternativa 2D y se puede reservar', async ({ page, demo }) => {
  await page.route('**/panoramas/multiple-1.png', (r) => r.fulfill({ contentType: 'image/png', body: png(64, 32) }))
  await demo()
  await abrirCancha(page)
  await expect(page.getByText('No se pudo mostrar el panorama')).toBeVisible()
  await libres(page, 1).first().click()
  await expect(page.getByText('Franja seleccionada').locator('visible=true')).toBeVisible()
})

test('[PAN-13] el calendario se usa mientras carga el panorama', async ({ page, demo }) => {
  await page.route('**/panoramas/**', () => {})
  await demo()
  await abrirCancha(page)
  await expect(page.getByText('Cargando panorama…')).toBeVisible()
  await libres(page, 1).first().click()
  await expect(page.getByText('Franja seleccionada').locator('visible=true')).toBeVisible()
})

// Utilidades del recorrido demo: estado sembrado, reloj fijo y sin conflictos al azar.
import { test as base, expect } from '@playwright/test'

export { expect }
export const ID = {
  multiple1: 'a1b2c3d4-0001-4000-8000-000000000001',
  tenis1: 'a1b2c3d4-0002-4000-8000-000000000002',
  multiple2: 'a1b2c3d4-0003-4000-8000-000000000003',
  futbol5: 'a1b2c3d4-0004-4000-8000-000000000004',
  futbol11: 'a1b2c3d4-0005-4000-8000-000000000005',
}
export const HOY = '2026-11-24' // martes
export const MANANA = '2026-11-25'
export const LUNES_SIGUIENTE = '2026-11-30'
const AHORA = `${HOY}T10:30:00-05:00`
const STATE = 'ud-demo-state-v1'

const at = (date, hour, min = 0) => new Date(`${date}T${String(hour).padStart(2, '0')}:${String(min).padStart(2, '0')}:00-05:00`)

/** Reserva del estudiante demo. `hour` admite fracciones (10.5 = 10:30). */
export const reserva = (id, { space = ID.multiple1, date = HOY, hour = 14, hours = 1, status = 'CONFIRMED', equipment = [] } = {}) => {
  const start = at(date, Math.floor(hour), Math.round((hour % 1) * 60))
  return {
    id, spaceId: space, userId: 'demo-student', status, equipment,
    startAt: start.toISOString(), endAt: new Date(start.getTime() + hours * 3_600_000).toISOString(),
    createdAt: at(date, 1).toISOString(), checkedInAt: status === 'IN_USE' ? start.toISOString() : null,
  }
}

const space = (id, name, openingTime, closingTime, disciplines, extra = {}) => ({
  id, name, capacity: 20, requirements: 'Calzado deportivo', openingTime, closingTime, status: 'ACTIVE', disciplines, ...extra,
})
export const estado = (extra = {}) => ({
  catalogVersion: 2,
  spaces: [
    space(ID.multiple1, 'Cancha múltiple 1', '08:00', '20:00', ['BASKETBALL', 'VOLLEYBALL']),
    space(ID.tenis1, 'Cancha de tenis 1', '06:00', '18:00', ['TENNIS'], { capacity: 4 }),
    space(ID.multiple2, 'Cancha múltiple 2', '06:00', '18:00', ['FOOTBALL_5', 'BASKETBALL']),
    space(ID.futbol5, 'Cancha fútbol 5', '07:00', '21:00', ['FOOTBALL_5'], { status: 'MAINTENANCE', capacity: 10 }),
    space(ID.futbol11, 'Cancha fútbol 11', '07:00', '21:00', ['FOOTBALL_11'], { capacity: 22 }),
  ],
  reservations: [],
  blocks: [],
  equipment: [
    { id: 'eq-balon', name: 'Balón de baloncesto', discipline: 'BASKETBALL', stock: 10, status: 'AVAILABLE' },
    { id: 'eq-voley', name: 'Balón de voleibol', discipline: 'VOLLEYBALL', stock: 8, status: 'AVAILABLE' },
    { id: 'eq-malla', name: 'Malla de voleibol', discipline: 'VOLLEYBALL', stock: 2, status: 'INACTIVE' },
    { id: 'eq-petos', name: 'Petos', discipline: null, stock: 20, status: 'AVAILABLE' },
  ],
  params: { weeklyHours: 4, noShows: 3 },
  ...extra,
})

/**
 * `demo({ role, state, time, random })`: prepara la página antes de navegar.
 * El estado solo se siembra una vez, para que sobreviva a las recargas.
 */
export const test = base.extend({
  errores: async ({ page }, use) => {
    const list = []
    page.on('pageerror', (e) => list.push(e.message))
    page.on('console', (m) => m.type() === 'error' && list.push(m.text()))
    await use(list)
  },
  demo: async ({ page }, use) => {
    await use(async ({ role = 'student', state = estado(), time = AHORA, random = 0.9 } = {}) => {
      // setFixedTime solo fija la fecha: clock.install también simula los temporizadores y congela las animaciones
      if (time) await page.clock.setFixedTime(new Date(time))
      await page.addInitScript(
        ({ role, state, random, key }) => {
          if (random != null) Math.random = () => random
          if (sessionStorage.getItem('qa')) return
          sessionStorage.setItem('qa', '1')
          if (role) localStorage.setItem('ud-token', `demo:${role}`)
          if (state) localStorage.setItem(key, JSON.stringify(state))
        },
        { role, state, random, key: STATE }
      )
    })
  },
})

export const leerEstado = (page) => page.evaluate((k) => JSON.parse(localStorage.getItem(k)), STATE)
export const titulo = (page, name) => page.getByRole('heading', { level: 1, name })

/** Columna de un día del calendario (0 = hoy). Solo hay 7 columnas en pantalla grande. */
export const columna = (page, day) => page.locator('[aria-busy] > div.border-l').nth(day)
export const libres = (page, day) => columna(page, day).locator('button:not([disabled])')
/** Celda de una hora concreta: la fila sale de la hora de apertura. */
export const celda = (page, day, hour, open = 8) => columna(page, day).locator('button').nth(hour - open)

export const abrirCancha = async (page, id = ID.multiple1) => {
  await page.goto(`/app/disponibilidad/${id}`)
  await expect(page.getByText(/En vivo/)).toBeVisible()
  await expect(page.locator('[aria-busy="false"]').first()).toBeVisible()
}
export const continuar = (page) => page.getByRole('button', { name: /^Continuar/ }).locator('visible=true').click()

/** Cambia de sesión en la misma pestaña, conservando los datos de la demo. */
export const entrarComo = async (page, role, path) => {
  await page.evaluate((r) => localStorage.setItem('ud-token', `demo:${r}`), role)
  await page.goto(path)
}
/** Elige una opción de un Select de SmoothUI por su etiqueta accesible. */
export const elegir = async (page, label, option) => {
  await page.getByLabel(label, { exact: true }).locator('visible=true').first().click()
  await page.getByRole('option', { name: option, exact: true }).click()
  await expect(page.getByRole('option')).toHaveCount(0) // la lista se cierra con animación
}
/** Diálogos de la app; los avisos (toast) también tienen rol de diálogo. */
export const dialogo = (page) => page.locator('[data-slot="dialog-content"]')
